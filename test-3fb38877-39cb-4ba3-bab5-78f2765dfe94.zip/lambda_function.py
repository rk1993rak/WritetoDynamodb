import boto3
import logging
logger = logging.getLogger()
def lambda_handler(event, context):
    logger.setLevel(logging.INFO)
    logger.info('got event{}'.format(event))
    logger.error('something went wrong')
    dynamodb = boto3.client('dynamodb')
    # 
    ContactId = event['Details']['ContactData']['Attributes']['ContactId']
    Brand = event['Details']['ContactData']['Attributes']['Brand']
    Country = event['Details']['ContactData']['Attributes']['Country']

    response_dict = {
        "ContactId": ContactId,
        "Brand": Brand,
        "Country": Country
    }
    # Constructing the item to put into DynamoDB
    item = {
        'ContactId': {'S': str(ContactId)},
        'Brand': {'S': str(Brand)},
        'Country': {'S': str(Country)}
    }
    print(item)

    # Writing the item to DynamoDB table
    try:
        dynamodb.put_item(
            TableName='Test',
            Item=item
        )
        return {'return': True}
    except Exception as e:
        return {'return': False, 'error_message': str(e)}
    

